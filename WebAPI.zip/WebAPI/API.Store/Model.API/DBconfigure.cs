﻿using System;
using System.Collections.Generic;
using System.Text;

namespace API.Store.Model.API
{
    public class DBconfigure:IDBconfigure
    {
        public string connStr { get; set; }
    }
}
