﻿using System;
using System.Collections.Generic;
using System.Text;

namespace API.Store.Model.API
{
    public interface IDBconfigure
    {
        string connStr { get; set; }
    }
}
